<script src=""></script>
<body>

<h2></h2>

<p>The slideshow is an object, with methods like next/previous:</p>

<img class="nature" src="" width="50%">
<img class="nature" src="" width="50%">
<img class="nature" src="" width="50%">

<p>
<button onclick="myShow.previous()">Previous</button>
<button onclick="myShow.next()">Next</button>
</p>

<script>
myShow = w3.slideshow(".nature", 0);
</script>
